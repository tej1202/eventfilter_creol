<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'creol_practicle' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '1-:9$)#:%[;G`bCTMx6h8<x4F=xQ1pt>$r@${2d0Zwd4N)QM=@Of:eAGx2z42&tJ' );
define( 'SECURE_AUTH_KEY',  'd5Pf_/Vi)q18SHL;RIRFAXt0sl<tp8./XYZxH%kIg#f~B<On*0aeFq72e)LsUrTy' );
define( 'LOGGED_IN_KEY',    'PiA.,>`DevPLQa_1f-OTHQ1L;l~9o!3P#I/q(;zm4:ykG)5D?/&G[R,,Kn}`X[:{' );
define( 'NONCE_KEY',        'oafADEtI[ft9r)qHca$(6$mh a`6yjk8YWhn6Fz`>RtwN665i^(-DBT|3W0h_(?$' );
define( 'AUTH_SALT',        ' rMnwmrvelofC4+;sn&70/NO^1!%);AHS2sX`hLj&3oJpoES+N/C&DL$5rWGW=f_' );
define( 'SECURE_AUTH_SALT', 'Bt`h+-`1)t=qq)!,(y!q/)|y[WJ~(etjl[0761sQgD{1]EB|nr3Fp>~ *WV(I,,m' );
define( 'LOGGED_IN_SALT',   '@Iu=-)P0.YSva{erkLQXP@X>bKL}H%!XqJ-4b[{r?ANtc@f<*>!UVdY0|tnK(82.' );
define( 'NONCE_SALT',       'g^*c7bQ25$?=21!1J<s.1uhG:ho)m;[hOn^,T,GXpMB$oG|x%mAtG!5a/$4>a{0@' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
